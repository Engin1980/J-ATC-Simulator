//package eng.jAtcSim.lib.speaking.parsing.shortParsing;
//
//class ParseDef {
//
//  public final String[] prefixes;
//  public final String pattern;
//  public final Class commandType;
//
//  public ParseDef(Class commandType, String pattern, String... prefixes) {
//    this.prefixes = prefixes;
//    this.pattern = pattern;
//    this.commandType = commandType;
//  }
//}
